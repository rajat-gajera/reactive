# Reactive Spring Boot POC - Backpressure Implementation

This application demonstrates reactive programming with Spring Boot WebFlux and comprehensive backpressure handling techniques using real external APIs.

## Features

### 1. External API Integration
- **JSONPlaceholder API**: Integrates with https://jsonplaceholder.typicode.com for posts and comments
- **WebClient Configuration**: Optimized for handling large datasets with memory management
- **Retry Mechanisms**: Exponential backoff retry strategies for resilient API calls

### 2. Backpressure Strategies Implemented

#### Buffer Strategy
- **Endpoint**: `/api/external/posts`
- **Implementation**: Uses `.buffer(10)` to process data in chunks
- **Use Case**: When you can afford to buffer some data in memory

#### Rate Limiting
- **Endpoint**: `/api/external/posts/rate-limited?maxPerSecond=5`
- **Implementation**: Uses `.window()` and `.take()` to control throughput
- **Use Case**: Protecting downstream services from being overwhelmed

#### Drop Strategy
- **Endpoint**: `/api/external/posts/backpressure/drop`
- **Implementation**: Uses `.onBackpressureDrop()` to discard overflow items
- **Use Case**: When losing some data is acceptable to maintain performance

#### Latest Strategy
- **Endpoint**: `/api/external/posts/backpressure/latest`
- **Implementation**: Uses `.onBackpressureLatest()` to keep only the newest item
- **Use Case**: Real-time scenarios where only the latest data matters

#### Error Strategy
- **Endpoint**: `/api/external/posts/backpressure/error`
- **Implementation**: Uses `.onBackpressureError()` to fail fast
- **Use Case**: When backpressure indicates a serious system problem

### 3. High-Throughput Data Processing

#### Data Stream Simulation
- **Endpoint**: `/api/external/data-stream`
- **Features**: 
  - Generates data every 10ms (100 items/second)
  - Demonstrates backpressure with fast producers
  - Uses `.onBackpressureLatest()` to handle overflow

#### Parallel Processing
- **Endpoint**: `/api/external/posts-with-comments`
- **Features**:
  - Fetches posts and their comments in parallel
  - Concurrency level control with `.flatMap(source, concurrency)`
  - Combines multiple reactive streams efficiently

### 4. Monitoring and Observability

#### Actuator Endpoints
- `/actuator/health` - Application health status
- `/actuator/metrics` - Reactor and application metrics
- `/actuator/prometheus` - Prometheus metrics export

#### Logging
- Debug level logging for reactive operations
- Backpressure event logging (drops, buffers, errors)
- Performance monitoring for throughput analysis

## API Endpoints

### Student Management (Original)
- `GET /api/students` - List all students
- `POST /api/students` - Create student
- `GET /api/students/{id}` - Get student by ID
- `PUT /api/students/{id}` - Update student
- `DELETE /api/students/{id}` - Delete student

### External API with Backpressure
- `GET /api/external/posts` - All posts with buffer backpressure
- `GET /api/external/posts/rate-limited?maxPerSecond=N` - Rate-limited posts
- `GET /api/external/posts/{id}/comments` - Comments with drop backpressure
- `GET /api/external/posts/backpressure/{strategy}` - Different backpressure strategies
- `GET /api/external/data-stream` - High-throughput data stream
- `GET /api/external/posts-with-comments` - Parallel processing demo
- `GET /api/external/posts/slow-consumer` - Slow consumer simulation

## Running the Application

```bash
# Build and run
./gradlew bootRun

# Run tests
./gradlew test

# Test APIs
chmod +x test-api.sh
./test-api.sh
```

## Backpressure Testing Scenarios

### 1. Fast Producer, Slow Consumer
```bash
curl -N "http://localhost:8081/api/external/posts/slow-consumer"
```
Demonstrates buffering and potential dropping of items.

### 2. Rate Limiting
```bash
curl -N "http://localhost:8081/api/external/posts/rate-limited?maxPerSecond=2"
```
Shows controlled throughput to protect downstream services.

### 3. High-Throughput Stream
```bash
curl -N "http://localhost:8081/api/external/data-stream"
```
Simulates real-time data processing with backpressure handling.

### 4. Concurrent Load Testing
```bash
# Multiple concurrent requests
for i in {1..10}; do
    curl -s -N "http://localhost:8081/api/external/posts" > /dev/null &
done
```

## Key Backpressure Concepts Demonstrated

1. **Buffering**: Temporary storage to smooth out rate differences
2. **Dropping**: Discarding items when buffers are full
3. **Rate Limiting**: Controlling production rate to match consumption
4. **Parallel Processing**: Using multiple threads to increase throughput
5. **Error Handling**: Failing fast when backpressure indicates problems
6. **Monitoring**: Observing backpressure events and system health

## Configuration

Key configuration properties in `application.properties`:
- `reactor.schedulers.defaultPoolSize=10` - Thread pool size
- `reactor.schedulers.defaultQueueSize=256` - Queue size for backpressure
- `spring.webflux.multipart.max-in-memory-size=10MB` - Memory limits

## Dependencies

- Spring Boot WebFlux
- Spring Boot Actuator
- Reactor Core with backpressure support
- WebClient for external API integration
- R2DBC for reactive database access
