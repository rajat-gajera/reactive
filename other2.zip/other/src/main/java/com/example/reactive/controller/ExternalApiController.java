package com.example.reactive.controller;

import com.example.reactive.model.Post;
import com.example.reactive.model.Comment;
import com.example.reactive.service.ExternalApiService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

import java.time.Duration;

@RestController
@RequestMapping("/api/external")
@RequiredArgsConstructor
@Slf4j
public class ExternalApiController {

    private final ExternalApiService externalApiService;

    /**
     * Stream posts with backpressure handling
     */
    @GetMapping(value = "/posts", produces = MediaType.APPLICATION_NDJSON_VALUE)
    public Flux<Post> getAllPosts() {
        log.info("Fetching all posts with backpressure handling");
        return externalApiService.getAllPostsWithBackpressure();
    }

    /**
     * Stream posts with rate limiting
     */
    @GetMapping(value = "/posts/rate-limited", produces = MediaType.APPLICATION_NDJSON_VALUE)
    public Flux<Post> getRateLimitedPosts(@RequestParam(defaultValue = "5") int maxPerSecond) {
        log.info("Fetching posts with rate limit: {} per second", maxPerSecond);
        return externalApiService.getPostsWithRateLimit(maxPerSecond);
    }

    /**
     * Get comments for a specific post
     */
    @GetMapping(value = "/posts/{postId}/comments", produces = MediaType.APPLICATION_NDJSON_VALUE)
    public Flux<Comment> getCommentsForPost(@PathVariable Long postId) {
        log.info("Fetching comments for post: {}", postId);
        return externalApiService.getCommentsForPost(postId);
    }

    /**
     * Demonstrate different backpressure strategies
     */
    @GetMapping(value = "/posts/backpressure/{strategy}", produces = MediaType.APPLICATION_NDJSON_VALUE)
    public Flux<Post> getPostsWithBackpressureStrategy(@PathVariable String strategy) {
        log.info("Fetching posts with backpressure strategy: {}", strategy);
        return externalApiService.getPostsWithDifferentBackpressureStrategies(strategy);
    }

    /**
     * High-throughput data stream demonstration
     */
    @GetMapping(value = "/data-stream", produces = MediaType.TEXT_PLAIN_VALUE)
    public Flux<String> getHighThroughputDataStream() {
        log.info("Starting high-throughput data stream");
        return externalApiService.getHighThroughputDataStream()
                .map(data -> data + "\n");
    }

    /**
     * Posts with their comments using parallel processing
     */
    @GetMapping(value = "/posts-with-comments", produces = MediaType.APPLICATION_NDJSON_VALUE)
    public Flux<ExternalApiService.PostWithComments> getPostsWithComments() {
        log.info("Fetching posts with comments using parallel processing");
        return externalApiService.getPostsWithComments();
    }

    /**
     * Slow consumer simulation - delays processing to test backpressure
     */
    @GetMapping(value = "/posts/slow-consumer", produces = MediaType.APPLICATION_NDJSON_VALUE)
    public Flux<Post> getPostsSlowConsumer() {
        log.info("Simulating slow consumer with backpressure");
        return externalApiService.getAllPostsWithBackpressure()
                .delayElements(Duration.ofSeconds(2)) // Simulate slow processing
                .doOnNext(post -> log.info("Slowly processed post: {}", post.getId()));
    }
}
