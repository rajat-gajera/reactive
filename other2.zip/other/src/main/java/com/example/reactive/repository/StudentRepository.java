package com.example.reactive.repository;

import com.example.reactive.model.Student;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface StudentRepository extends ReactiveCrudRepository<Student, Long> {

    Flux<Student> findByDepartment(String department);

    @Query("SELECT * FROM students WHERE age >= :minAge")
    Flux<Student> findByAgeGreaterThanEqual(Integer minAge);

    Flux<Student> findByNameContainingIgnoreCase(String name);
}
