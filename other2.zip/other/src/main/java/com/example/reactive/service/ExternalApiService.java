package com.example.reactive.service;

import com.example.reactive.model.Post;
import com.example.reactive.model.Comment;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lombok.Data;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.concurrent.ThreadLocalRandom;

@Service
@RequiredArgsConstructor
@Slf4j
public class ExternalApiService {

    private final WebClient webClient;

    /**
     * Fetches all posts with backpressure handling using buffer and parallel processing
     */
    public Flux<Post> getAllPostsWithBackpressure() {
        return webClient.get()
                .uri("/posts")
                .retrieve()
                .bodyToFlux(Post.class)
                .doOnNext(post -> log.debug("Received post: {}", post.getId()))
                .buffer(10) // Buffer posts in chunks of 10 to handle backpressure
                .flatMap(posts ->
                    Flux.fromIterable(posts)
                        .subscribeOn(Schedulers.boundedElastic())
                        .delayElements(Duration.ofMillis(100)) // Simulate processing delay
                )
                .onBackpressureBuffer(50,
                    dropped -> log.warn("Dropped post due to backpressure: {}", dropped))
                .retryWhen(Retry.backoff(3, Duration.ofSeconds(1)))
                .doOnError(error -> log.error("Error fetching posts: ", error));
    }

    /**
     * Fetches posts with controlled rate limiting using window and take operators
     */
    public Flux<Post> getPostsWithRateLimit(int maxPostsPerSecond) {
        return getAllPostsWithBackpressure()
                .window(Duration.ofSeconds(1))
                .flatMap(window -> window.take(maxPostsPerSecond))
                .doOnNext(post -> log.info("Rate-limited post: {}", post.getId()));
    }

    /**
     * Fetches comments for a post with backpressure handling
     */
    public Flux<Comment> getCommentsForPost(Long postId) {
        return webClient.get()
                .uri("/posts/{postId}/comments", postId)
                .retrieve()
                .bodyToFlux(Comment.class)
                .doOnNext(comment -> log.debug("Received comment: {} for post: {}", comment.getId(), postId))
                .onBackpressureDrop(dropped ->
                    log.warn("Dropped comment due to backpressure: {}", dropped.getId()))
                .retryWhen(Retry.backoff(2, Duration.ofSeconds(1)));
    }

    /**
     * Simulates a high-throughput data stream with backpressure handling
     */
    public Flux<String> getHighThroughputDataStream() {
        return Flux.interval(Duration.ofMillis(10))
                .map(i -> "Data-" + i + "-" + ThreadLocalRandom.current().nextInt(1000))
                .doOnNext(data -> log.debug("Generated data: {}", data))
                .onBackpressureLatest() // Keep only the latest item when consumer is slow
                .take(Duration.ofMinutes(1)) // Limit to 1 minute of data
                .doOnNext(data -> log.info("Processed data: {}", data));
    }

    /**
     * Demonstrates different backpressure strategies
     */
    public Flux<Post> getPostsWithDifferentBackpressureStrategies(String strategy) {
        Flux<Post> baseFlux = webClient.get()
                .uri("/posts")
                .retrieve()
                .bodyToFlux(Post.class)
                .delayElements(Duration.ofMillis(50)); // Simulate fast producer

        return switch (strategy.toLowerCase()) {
            case "buffer" -> baseFlux.onBackpressureBuffer(20);
            case "drop" -> baseFlux.onBackpressureDrop(dropped ->
                log.warn("Dropped post: {}", dropped.getId()));
            case "latest" -> baseFlux.onBackpressureLatest();
            case "error" -> baseFlux.onBackpressureError();
            default -> baseFlux.onBackpressureBuffer();
        };
    }

    /**
     * Fetches posts and their comments with parallel processing and backpressure
     */
    public Flux<PostWithComments> getPostsWithComments() {
        return getAllPostsWithBackpressure()
                .take(10) // Limit to first 10 posts for demo
                .flatMap(post ->
                    getCommentsForPost(post.getId())
                        .collectList()
                        .map(comments -> new PostWithComments(post, comments))
                        .subscribeOn(Schedulers.parallel()),
                    3 // Concurrency level of 3
                )
                .onBackpressureBuffer(15,
                    dropped -> log.warn("Dropped PostWithComments due to backpressure"));
    }

    /**
     * Inner class to represent a post with its comments
     */
    @Data
    @AllArgsConstructor
    public static class PostWithComments {
        private final Post post;
        private final java.util.List<Comment> comments;
    }
}
