package com.example.reactive.service;

import com.example.reactive.model.Post;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;
import reactor.test.publisher.TestPublisher;

import java.time.Duration;

@SpringBootTest
@TestPropertySource(properties = {
    "logging.level.com.example.reactive=DEBUG"
})
class ExternalApiServiceTest {

    @Autowired
    private ExternalApiService externalApiService;

    @Test
    void testGetAllPostsWithBackpressure() {
        StepVerifier.create(
                externalApiService.getAllPostsWithBackpressure()
                    .take(5) // Take only first 5 posts for test
            )
            .expectNextCount(5)
            .verifyComplete();
    }

    @Test
    void testGetPostsWithRateLimit() {
        StepVerifier.withVirtualTime(() ->
                externalApiService.getPostsWithRateLimit(2)
                    .take(4) // Take 4 posts
            )
            .expectSubscription()
            .expectNextCount(2) // First 2 posts in first second
            .thenAwait(Duration.ofSeconds(1))
            .expectNextCount(2) // Next 2 posts in second second
            .verifyComplete();
    }

    @Test
    void testGetCommentsForPost() {
        StepVerifier.create(
                externalApiService.getCommentsForPost(1L)
                    .take(3)
            )
            .expectNextCount(3)
            .verifyComplete();
    }

    @Test
    void testHighThroughputDataStream() {
        StepVerifier.withVirtualTime(() ->
                externalApiService.getHighThroughputDataStream()
                    .take(10)
            )
            .expectSubscription()
            .expectNextCount(10)
            .verifyComplete();
    }

    @Test
    void testBackpressureStrategies() {
        // Test buffer strategy
        StepVerifier.create(
                externalApiService.getPostsWithDifferentBackpressureStrategies("buffer")
                    .take(5)
            )
            .expectNextCount(5)
            .verifyComplete();

        // Test drop strategy
        StepVerifier.create(
                externalApiService.getPostsWithDifferentBackpressureStrategies("drop")
                    .take(3)
            )
            .expectNextCount(3)
            .verifyComplete();
    }

    @Test
    void testBackpressureWithSlowConsumer() {
        TestPublisher<String> testPublisher = TestPublisher.create();

        Flux<String> slowConsumer = testPublisher.flux()
            .delayElements(Duration.ofMillis(100))
            .onBackpressureBuffer(5);

        StepVerifier.create(slowConsumer.take(3))
            .then(() -> {
                testPublisher.next("item1");
                testPublisher.next("item2");
                testPublisher.next("item3");
            })
            .expectNext("item1", "item2", "item3")
            .verifyComplete();
    }
}
