#!/bin/bash

echo "=== Reactive Spring Boot POC - Backpressure API Testing ==="
echo "Starting comprehensive API tests..."

BASE_URL="http://localhost:8082"

echo -e "\n1. Testing basic student endpoints..."
curl -s "$BASE_URL/api/students" | head -5

echo -e "\n2. Testing external API - All posts with backpressure (first 5)..."
curl -s -N "$BASE_URL/api/external/posts" | head -5

echo -e "\n3. Testing rate-limited posts (2 per second)..."
curl -s -N "$BASE_URL/api/external/posts/rate-limited?maxPerSecond=2" | head -6

echo -e "\n4. Testing comments for post 1..."
curl -s -N "$BASE_URL/api/external/posts/1/comments" | head -3

echo -e "\n5. Testing backpressure strategies:"

echo -e "\n   a) Buffer strategy..."
curl -s -N "$BASE_URL/api/external/posts/backpressure/buffer" | head -3

echo -e "\n   b) Drop strategy..."
curl -s -N "$BASE_URL/api/external/posts/backpressure/drop" | head -3

echo -e "\n   c) Latest strategy..."
curl -s -N "$BASE_URL/api/external/posts/backpressure/latest" | head -3

echo -e "\n6. Testing high-throughput data stream (10 seconds)..."
timeout 10s curl -s -N "$BASE_URL/api/external/data-stream" | head -20

echo -e "\n7. Testing posts with comments (parallel processing)..."
curl -s -N "$BASE_URL/api/external/posts-with-comments" | head -2

echo -e "\n8. Testing slow consumer simulation..."
timeout 15s curl -s -N "$BASE_URL/api/external/posts/slow-consumer" | head -3

echo -e "\n9. Testing actuator health endpoint..."
curl -s "$BASE_URL/actuator/health" | jq '.'

echo -e "\n10. Testing actuator metrics..."
curl -s "$BASE_URL/actuator/metrics" | jq '.names[] | select(contains("reactor"))'

echo -e "\n=== Load Testing with multiple concurrent requests ==="

echo -e "\nTesting concurrent requests to posts endpoint..."
for i in {1..5}; do
    curl -s -N "$BASE_URL/api/external/posts" > /dev/null &
done
wait

echo -e "\nAll tests completed! Check the application logs for backpressure handling details."
