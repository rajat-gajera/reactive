package com.example.reactive.service;

import com.example.reactive.model.Student;
import com.example.reactive.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;

@Service
@RequiredArgsConstructor
@Slf4j
public class StudentService {

    private final StudentRepository studentRepository;

    public Flux<Student> getAllStudents() {
        log.info("Fetching all students");
        return studentRepository.findAll()
                .doOnNext(student -> log.debug("Found student: {}", student.getName()));
    }

    public Mono<Student> getStudentById(Long id) {
        log.info("Fetching student with id: {}", id);
        return studentRepository.findById(id)
                .doOnNext(student -> log.debug("Found student: {}", student.getName()))
                .doOnError(error -> log.error("Error fetching student with id: {}", id, error));
    }

    public Mono<Student> createStudent(Student student) {
        log.info("Creating new student: {}", student.getName());
        return studentRepository.save(student)
                .doOnNext(savedStudent -> log.info("Created student with id: {}", savedStudent.getId()))
                .doOnError(error -> log.error("Error creating student: {}", student.getName(), error));
    }

    public Mono<Student> updateStudent(Long id, Student student) {
        log.info("Updating student with id: {}", id);
        return studentRepository.findById(id)
                .flatMap(existingStudent -> {
                    existingStudent.setName(student.getName());
                    existingStudent.setEmail(student.getEmail());
                    existingStudent.setAge(student.getAge());
                    existingStudent.setDepartment(student.getDepartment());
                    return studentRepository.save(existingStudent);
                })
                .doOnNext(updatedStudent -> log.info("Updated student: {}", updatedStudent.getName()))
                .doOnError(error -> log.error("Error updating student with id: {}", id, error));
    }

    public Mono<Void> deleteStudent(Long id) {
        log.info("Deleting student with id: {}", id);
        return studentRepository.deleteById(id)
                .doOnSuccess(unused -> log.info("Successfully deleted student with id: {}", id))
                .doOnError(error -> log.error("Error deleting student with id: {}", id, error));
    }

    public Flux<Student> getStudentsByDepartment(String department) {
        log.info("Fetching students by department: {}", department);
        return studentRepository.findByDepartment(department)
                .delayElements(Duration.ofMillis(100)); // Simulate processing delay
    }

    public Flux<Student> getStudentsByMinAge(Integer minAge) {
        log.info("Fetching students with minimum age: {}", minAge);
        return studentRepository.findByAgeGreaterThanEqual(minAge);
    }

    public Flux<Student> searchStudentsByName(String name) {
        log.info("Searching students by name: {}", name);
        return studentRepository.findByNameContainingIgnoreCase(name);
    }
}
