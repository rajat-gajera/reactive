package com.example.reactive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@EnableR2dbcRepositories
@Slf4j
public class ReactiveSpringBootPocApplication {

	public static void main(String[] args) {
		log.info("Starting Reactive Spring Boot POC Application...");
		SpringApplication.run(ReactiveSpringBootPocApplication.class, args);
		log.info("Application started successfully!");
		log.info("API endpoints available at: http://localhost:8080/api/students");
		log.info("H2 Console available at: http://localhost:8080/h2-console");
	}

}
