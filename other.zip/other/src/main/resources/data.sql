INSERT INTO students (name, email, age, department) VALUES
('John Doe', 'john.doe@university.edu', 20, 'Computer Science'),
('Jane Smith', 'jane.smith@university.edu', 22, 'Mathematics'),
('Mike Johnson', 'mike.johnson@university.edu', 21, 'Computer Science'),
('Sarah Wilson', 'sarah.wilson@university.edu', 23, 'Physics'),
('David Brown', 'david.brown@university.edu', 19, 'Chemistry'),
('Emily Davis', 'emily.davis@university.edu', 24, 'Computer Science'),
('Robert Miller', 'robert.miller@university.edu', 20, 'Mathematics'),
('Lisa Anderson', 'lisa.anderson@university.edu', 22, 'Physics');

