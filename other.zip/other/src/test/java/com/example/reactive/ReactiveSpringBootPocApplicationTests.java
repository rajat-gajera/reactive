package com.example.reactive;

import com.example.reactive.model.Student;
import com.example.reactive.repository.StudentRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWebTestClient
class ReactiveSpringBootPocApplicationTests {

	@Autowired
	private WebTestClient webTestClient;

	@Autowired
	private StudentRepository studentRepository;

	@Test
	void contextLoads() {
		// Verify that the application context loads successfully
	}

	@Test
	void testGetAllStudents() {
		webTestClient.get()
				.uri("/api/students")
				.accept(MediaType.APPLICATION_JSON)
				.exchange()
				.expectStatus().isOk()
				.expectHeader().contentType(MediaType.APPLICATION_JSON)
				.expectBodyList(Student.class)
				.hasSize(8); // We inserted 8 students in data.sql
	}

	@Test
	void testGetStudentById() {
		webTestClient.get()
				.uri("/api/students/1")
				.accept(MediaType.APPLICATION_JSON)
				.exchange()
				.expectStatus().isOk()
				.expectHeader().contentType(MediaType.APPLICATION_JSON)
				.expectBody(Student.class)
				.value(student -> {
					assert student.getName().equals("John Doe");
					assert student.getEmail().equals("john.doe@university.edu");
				});
	}

	@Test
	void testCreateStudent() {
		Student newStudent = new Student(null, "Test Student", "test@university.edu", 25, "Engineering");

		webTestClient.post()
				.uri("/api/students")
				.contentType(MediaType.APPLICATION_JSON)
				.body(Mono.just(newStudent), Student.class)
				.exchange()
				.expectStatus().isCreated()
				.expectHeader().contentType(MediaType.APPLICATION_JSON)
				.expectBody(Student.class)
				.value(student -> {
					assert student.getName().equals("Test Student");
					assert student.getId() != null;
				});
	}

	@Test
	void testGetStudentsByDepartment() {
		webTestClient.get()
				.uri("/api/students/department/Computer Science")
				.accept(MediaType.APPLICATION_JSON)
				.exchange()
				.expectStatus().isOk()
				.expectHeader().contentType(MediaType.APPLICATION_JSON)
				.expectBodyList(Student.class)
				.hasSize(3); // 3 Computer Science students in data.sql
	}

	@Test
	void testStreamStudents() {
		webTestClient.get()
				.uri("/api/students/stream")
				.accept(MediaType.TEXT_EVENT_STREAM)
				.exchange()
				.expectStatus().isOk()
				.expectHeader().contentType(MediaType.TEXT_EVENT_STREAM_VALUE)
				.expectBodyList(Student.class)
				.hasSize(8);
	}
}
