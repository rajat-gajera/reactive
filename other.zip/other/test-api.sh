#!/bin/bash

echo "=== Reactive Spring Boot WebFlux API Test ==="
echo ""

# Test if application is running
echo "1. Testing if application is running..."
response=$(curl -s -w "%{http_code}" -o /dev/null http://localhost:8081/api/students)
if [ "$response" = "200" ]; then
    echo "✅ Application is running on port 8081"
else
    echo "❌ Application not responding. Status: $response"
    exit 1
fi

echo ""
echo "2. Getting all students (Reactive Flux<Student>)..."
curl -s http://localhost:8081/api/students | head -50

echo ""
echo ""
echo "3. Getting student by ID (Reactive Mono<Student>)..."
curl -s http://localhost:8081/api/students/1

echo ""
echo ""
echo "4. Creating a new student (POST)..."
curl -s -X POST http://localhost:8081/api/students \
  -H "Content-Type: application/json" \
  -d '{"name":"Test Student","email":"test@university.edu","age":25,"department":"Engineering"}'

echo ""
echo ""
echo "5. Getting students by department (Computer Science)..."
curl -s "http://localhost:8081/api/students/department/Computer%20Science"

echo ""
echo ""
echo "6. Testing Server-Sent Events streaming (first 3 events)..."
timeout 5s curl -s -N http://localhost:8081/api/students/stream | head -10

echo ""
echo ""
echo "=== Test Complete ==="
echo "Application is successfully running with reactive WebFlux!"
